//
//  RTMAudioInfo.h
//  Rtm
//
//  Created by zsl on 2020/8/4.
//  Copyright © 2020 FunPlus. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface RTMAudioInfo : NSObject
//@property(nonatomic,copy)NSString * sourceLanguage;
//@property(nonatomic,copy)NSString * recognizedLanguage;
//@property(nonatomic,copy)NSString * recognizedText;
//@property(nonatomic,assign)int duration;
@end

NS_ASSUME_NONNULL_END
