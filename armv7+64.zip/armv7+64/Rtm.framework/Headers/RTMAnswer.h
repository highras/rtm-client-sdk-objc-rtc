//
//  RTMAnswer.h
//  Rtm
//
//  Created by zsl on 2019/12/13.
//  Copyright © 2019 FunPlus. All rights reserved.
//

#import "FPNNAnswer.h"

NS_ASSUME_NONNULL_BEGIN

@interface RTMAnswer : FPNNAnswer

@end

NS_ASSUME_NONNULL_END
